package com.weidi.customadapter;

import com.weidi.customadapter.interfaces.IMultiItemViewType;

public abstract class SimpleMulItemViewType<T> implements IMultiItemViewType<T> {

    @Override
    public int getViewTypeCount() {
        return 1;
    }

}
