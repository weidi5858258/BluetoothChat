package com.weidi.customadapter;

import android.content.Context;
import android.database.DataSetObservable;
import android.database.DataSetObserver;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SpinnerAdapter;

import com.weidi.customadapter.interfaces.IMultiItemViewType;

import java.util.List;

abstract class CustomListViewAdapter<T> extends CustomRecyclerViewAdapter<T>
        implements
        ListAdapter,
        SpinnerAdapter {

    private AbsListView mAbsListView;

    private DataSetObservable mDataSetObservable = new DataSetObservable();

    public CustomListViewAdapter(Context context, List<T> list, int layoutResId) {
        super(context, list, layoutResId);
    }

    public CustomListViewAdapter(Context context, List<T> list, IMultiItemViewType<T>
            mulItemViewType) {
        super(context, list, mulItemViewType);
    }

    /**
     * @see android.widget.BaseAdapter#getCount().
     */
    @Override
    public int getCount() {
        return mData == null ? 0 : mData.size();
    }

    /**
     * @see android.widget.BaseAdapter#getItem(int).
     */
    @Override
    public T getItem(int position) {
        if (position >= mData.size())
            return null;
        return mData.get(position);
    }

    /**
     * @see android.widget.BaseAdapter#getItemId(int).
     */
    @Override
    public long getItemId(int position) {
        return position;
    }

    /**
     * @see android.widget.BaseAdapter#getViewTypeCount().
     */
    @Override
    public int getViewTypeCount() {
        if (mMultiItemViewType != null)
            return mMultiItemViewType.getViewTypeCount();
        return 1;
    }

    /**
     * @see android.widget.BaseAdapter#getView(int, View, ViewGroup)
     */
    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        if (mAbsListView == null && parent instanceof AbsListView) {
            mAbsListView = (AbsListView) parent;
        }
        final CustomViewHolder holder = onCreate(convertView, parent, getItemViewType(position));
        T item = getItem(position);
        onBind(holder, getItemViewType(position), position, item);
        addLoadAnimation(holder); // Load animation
        return holder.itemView;
    }

    /**
     * @see android.widget.BaseAdapter#areAllItemsEnabled().
     */
    @Override
    public boolean areAllItemsEnabled() {
        return true;
    }

    /**
     * @see android.widget.BaseAdapter#isEnabled(int).
     */
    @Override
    public boolean isEnabled(int position) {
        return true;
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        return getView(position, convertView, parent);
    }

    @Override
    public void registerDataSetObserver(DataSetObserver observer) {
        mDataSetObservable.registerObserver(observer);
    }

    @Override
    public void unregisterDataSetObserver(DataSetObserver observer) {
        mDataSetObservable.unregisterObserver(observer);
    }

    public void notifyDataSetHasChanged() {
        if (mRecyclerView == null)
            mDataSetObservable.notifyChanged();
    }

    public void notifyDataSetInvalidated() {
        if (mRecyclerView == null)
            mDataSetObservable.notifyInvalidated();
    }



    /**
     * Note that you must override this method if using <code>ListView</code> with multiple item
     * types.
     * <p>
     * 在使用ListView的多布局的情况下,你必须重写此方法,因为ListView和RV的实现机制不同。
     *
     * @see android.widget.BaseAdapter#getItemViewType(int).
     */
    @Override
    public int getItemViewType(int position) {
        return super.getItemViewType(position);
    }


    @Override
    public void addHeaderView(View header) {
        if (mAbsListView != null && mAbsListView instanceof ListView) {
            ((ListView) mAbsListView).addHeaderView(header);
            mHeaderView = header;
        } else {
            super.addHeaderView(header);
        }
    }

    @Override
    public boolean removeHeaderView() {
        if (mAbsListView != null && mAbsListView instanceof ListView) {
            return ((ListView) mAbsListView).removeHeaderView(mHeaderView);
        } else {
            return super.removeHeaderView();
        }
    }

    @Override
    public boolean hasHeaderView() {
        if (mAbsListView != null && mAbsListView instanceof ListView) {
            return ((ListView) mAbsListView).getHeaderViewsCount() > 0;
        } else {
            return super.hasHeaderView();
        }
    }

    @Override
    public void addFooterView(View footer) {
        if (mAbsListView != null && mAbsListView instanceof ListView) {
            ((ListView) mAbsListView).addFooterView(footer);
            mFooterView = footer;
        } else {
            super.addFooterView(footer);
        }
    }

    @Override
    public boolean removeFooterView() {
        if (mAbsListView != null && mAbsListView instanceof ListView) {
            return ((ListView) mAbsListView).removeFooterView(mFooterView);
        } else {
            return super.removeFooterView();
        }
    }

    @Override
    public boolean hasFooterView() {
        if (mAbsListView != null && mAbsListView instanceof ListView) {
            return ((ListView) mAbsListView).getFooterViewsCount() > 0;
        } else {
            return super.hasFooterView();
        }
    }

}
